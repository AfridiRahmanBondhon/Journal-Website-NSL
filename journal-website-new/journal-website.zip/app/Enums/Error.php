<?php

namespace App\Enums;

enum Error
{
    case ACCESS_RESTRICTED;
}
