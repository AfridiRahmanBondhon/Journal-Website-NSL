<?php

/**
 * @Nogor Solutions Ltd
 */

namespace App\Models;

use App\Models\Base\BaseModel;

class Feature extends BaseModel
{
    protected $guarded = ['id'];
    
    protected $logName = "Feature";

    // file image push

    // date format
}
