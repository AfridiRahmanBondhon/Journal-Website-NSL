<?php

/**
 * @Nogor Solutions Ltd
 */

namespace App\Models;

use App\Models\Base\BaseModel;

class Journal extends BaseModel
{
    protected $guarded = ['id'];
    
    protected $logName = "Journal";

    // file image push

    // date format
}
