<?php

/**
 * @Nogor Solutions Ltd
 */

namespace App\Models;

use App\Models\Base\BaseModel;

class Order extends BaseModel
{
    protected $guarded = ['id'];
    
    protected $logName = "Order";

    // file image push

    // date format
}
