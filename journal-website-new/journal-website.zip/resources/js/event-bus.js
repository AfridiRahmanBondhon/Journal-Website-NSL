/*
  The event bus handles the communication between components.
*/

import mitt from 'mitt'
export const EventBus = mitt();

