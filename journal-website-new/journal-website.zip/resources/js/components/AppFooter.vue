<template>
  <div class="content-part footer-bottom-part">
    <footer>
      Copyright &copy; {{ new Date().toISOString().slice(0, 4) }} Nogor Solution
      Limited. All Rights Reserved.
    </footer>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>
