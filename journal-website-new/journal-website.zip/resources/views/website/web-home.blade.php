@extends('website.layouts.web-layouts')
@section('title', 'Nogor Solutions Limited')
@section('content')
    @include('website.partials.slider')
@endsection  
